# encoding: utf-8
#
# This file is a part of Redmine CRM (redmine_contacts) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2010-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_contacts is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_contacts is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_contacts.  If not, see <http://www.gnu.org/licenses/>.


require File.expand_path('../../test_helper', __FILE__)

class DealImportTest < ActiveSupport::TestCase
  fixtures :projects, :users

  RedmineContacts::TestCase.create_fixtures(Redmine::Plugin.find(:redmine_contacts).directory + '/test/fixtures/', [:contacts,
                                                                                                                    :contacts_projects,
                                                                                                                    :deals,
                                                                                                                    :deal_statuses,
                                                                                                                    :deal_categories])

  def test_open_correct_csv
    assert_difference('Deal.count', 1, 'Should have 1 deal in the database') do
      deal_import = generate_import_with_mapping
      assert deal_import.run, 1
      assert_equal 1, deal_import.items.count, 'Should find 1 deal in file'
    end
    deal = Deal.last
    assert_equal 2, deal.status_id, "Status doesn't mach"
    assert_equal 1, deal.category_id, 'Category should be Design'
    assert_equal 'rhill', deal.assigned_to.login, 'Assignee should be Robert Hill (rhill)'
  end

  protected

  def generate_import(fixture_name='deals_correct.csv')
    import = DealImport.new
    import.user_id = 2
    import.file = Rack::Test::UploadedFile.new(redmine_contacts_fixture_files_path + fixture_name, 'text/csv')
    import.save!
    import
  end

  def generate_import_with_mapping(fixture_name='deals_correct.csv')
    import = generate_import(fixture_name)

    import.settings = {
      'separator' => ';',
      'wrapper' => '"',
      'encoding' => 'UTF-8',
      'date_format' => '%m/%d/%Y',
      'mapping' => {'project_id' => '1', 'name' => '1', 'status' => '7', 'category' => '9', 'assigned_to' => '6'}
    }
    import.save!
    import
  end
end if Redmine::VERSION.to_s >= '4.1'
